// Projecto BlueDroid - Carro Controlado por Android via Bluetooth
// 2015 @ ESTSetúbal, Jorge Martins & Manuel Ferreira
// --- Rotinas de Apoio --- 

void inicializacao_pinos(void) {
  pinMode(LUZ, OUTPUT); digitalWrite (LUZ, LOW);
  pinMode (LUZ2, OUTPUT); digitalWrite (LUZ2, LOW);
  pinMode(LUZ_RE, OUTPUT); digitalWrite (LUZ_RE, LOW);
  analogReference(EXTERNAL); 
}

void travar_carro (void) {
  Motor1.sentido(TRAVAR); Motor2.sentido(TRAVAR);
  Motor1.velocidade(255); Motor2.velocidade(255);
}

void mede_carga_da_bateria(void){
  
   if ( (timeElapsed_bateria > interval_bateria) and (flag_movimento == false) and (luzes_on_off==LOW)) {
      if (index_bat < ORDEM_FILTRO) {
        A0_Value [index_bat] = analogRead(A0);  // guarda leitura da bateria 
        index_bat++;                            // no array
      } else {
        A0_Value_media = 0;
        for (int i = 0; i <= 9; i++) {          // calcula a média
          A0_Value_media = A0_Value_media + A0_Value [i]/ORDEM_FILTRO;
        } 
        Voltage_AO = (A0_Value_media * 4.12 / 1024);
        Vbat = Voltage_AO * ((R1+R2)/R2);
        carga_bateria = 100 * (-0.2641 * Vbat * Vbat + 4.6112 * Vbat - 19.137);
        //carga_bateria = 35;
        if (carga_bateria > 99) carga_bateria = 99;
              
        //Serial.print(carga_bateria,DEC); Serial.print("%  ");
        //Serial.print ("("); Serial.print (Vbat); Serial.print(" V)\n\r");
        Bluetooth.write("B"); 
        if (carga_bateria < 10) Bluetooth.write("0");
        Bluetooth.println(carga_bateria,DEC);
        index_bat = 0;
      }
      timeElapsed_bateria = 0;
   }
} 
   
void ping_process (void) {
   if (timeElapsed_send_ping > 3000) { // envia um ping a cada 3 segundos 
      Bluetooth.println("P");
      timeElapsed_send_ping = 0; 
   }
   if (timeElapsed_receive_ping > 10000) {   // se ao fim de 3 segundos nã0
      flag_stop = true;                    // obtiver resposta ativa o mode
      travar_carro();
      Serial << "Stop" << endl;
      //tone (BUZINA, 1600); delay (50); noTone(BUZINA); pinMode(BUZINA, INPUT); 
      //delay (500);
      //tone (BUZINA, 1600); delay (100); noTone(BUZINA); pinMode(BUZINA, INPUT); delay (500);
      //tone (BUZINA, 1600); delay (100); noTone(BUZINA); pinMode(BUZINA, INPUT);
      timeElapsed_receive_ping =0;
   }  
}  
 
void desliga_beep (void) {
  noTone(BUZINA);
  pinMode(BUZINA, INPUT);
}  
 
void led_marcha_atras (void) {
  if (led_marcha_atras_count > 300) {
    digitalWrite(LUZ_RE, HIGH);
  } 
  if (led_marcha_atras_count > 400){
    digitalWrite(LUZ_RE, LOW);
    led_marcha_atras_count = 0;
  } 
}

void medir_distancia_frontal(void) {
    //distancia = ultrasonic.Ranging(CM);
    switch (ultrasonic_stop_count) {
      case (0):                           // na primeira medição inferior a 30 cm passa de estado
        if (distancia <= 30) ultrasonic_stop_count = 1; 
        break;
      case (1):                           // na segunda medição inferior a 30 cm passa de estado
        if (distancia <= 30) ultrasonic_stop_count = 2; 
        break;          
      case (2):
        if (distancia <= 30) {            // na terceira medição inferior a 30 cm pára 
          travar_carro();
          Serial << "D: " << distancia  ;
          Bluetooth << "D" << distancia ;
        }  
        ultrasonic_stop_count = 0;
        break;
    }
}



