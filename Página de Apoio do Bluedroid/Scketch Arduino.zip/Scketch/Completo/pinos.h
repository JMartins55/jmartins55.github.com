// Projecto BlueDroid - Carro Controlado por Android via Bluetooth
// 2015 @ ESTSetúbal, Jorge Martins & Manuel Ferreira
// --- Declaração dos Pinos --- 

#define BT_TxD 2    // Pino de TxD do módulo Bluetooth
#define BT_RxD 3    // Pino de RxD do módulo Bluetooth

#define BUZINA  4   // Pino de ativação da Buzina 
#define LUZ     5   // Pino de ativação das luzes frontais //(*) ver abaixo
#define LUZ2    13  // Pino de ativação das luzes frontais //(*) ver abaixo
#define IN1     9   // Pino IN1 da ponte H do Motor 1
#define IN2     8   // Pino IN2 da ponte H do Motor 1
#define IN3     7   // Pino IN3 da ponte H do Motor 2
#define IN4     6   // Pino IN4 da ponte H do Motor 2
#define EN_M1   10  // Pino de enable do Motor 1
#define EN_M2   11  // Pino de enable do Motor 2
#define VMB     A0  // Pino para leitura da tensão da beteria  
#define LUZ_RE  12  // Pino para ativação da luz de marcha-atrás

// (*) No projeto Bluedroid ambas as luzer são ligadas com a linha D5
//     Na escola de verão D5 é a luz da frente do lado direito e
//     D13 é a luz da frente do lado esquerdo

