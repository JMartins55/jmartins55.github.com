// Projecto BlueDroid - Carro Controlado por Android via Bluetooth
// 2015 @ ESTSetúbal, Jorge Martins & Manuel Ferreira
// --- Declaração de Variáveis e Criação de Objetos --- 

//cObjectos de Controlo dos Motores
L298 Motor1 (EN_M1, IN1, IN2);         // Ponte H do motor 1
L298 Motor2 (EN_M2, IN3, IN4);         // Ponte H do motor 2
#define PWM_VIRAR 80   // Valor de PWM na rotação do carro
#define PWM_FRENTE 220 // Valor de PWM na deslocação do carro
#define PWM_STEP 10    // Valor do incremento do arranque suave
#define INIT_PWM 120 // Valor da velocidade inicial
int pwm_speed = INIT_PWM;  // Velocidade atual do carro

//Marcha a Trás
elapsedMillis led_marcha_atras_count;
char flag_tras = false;

// Medidor de distancia frontal
#define FLAG_DISTANCIA false
//Ultrasonic ultrasonic(HCSR04_TRG,HCSR04_ECHO);
long distancia;
char flag_frente = false;
char ultrasonic_stop_count = 0;

// Bluetooth
SoftwareSerial Bluetooth(BT_TxD, BT_RxD); 
char comando;                  // comando recebido do android
char flag_led=0;

// Ping
elapsedMillis timeElapsed_receive_ping ; 
elapsedMillis timeElapsed_send_ping ; 
char flag_stop = false;

// Leitura da carga da bateria
#define ORDEM_FILTRO 10
char flag_movimento = false;
elapsedMillis timeElapsed_bateria;
long interval_bateria = 1000; // 10 segundos
int A0_Value[ORDEM_FILTRO];   
int A0_Value_media;
float Voltage_AO, Vbat;
int carga_bateria;
float R1 = 15000, R2 = 12000;
int index_bat = 0;
int luzes_on_off;

